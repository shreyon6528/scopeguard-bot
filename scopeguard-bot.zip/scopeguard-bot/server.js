require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const { v4: uuidv4 } = require('uuid');
const Stripe = require('stripe');

const app = express();
const stripe = Stripe(process.env.STRIPE_SECRET_KEY || '');

const FREE_MESSAGE_LIMIT = 5;
const PORT = process.env.PORT || 3000;
const DOMAIN = process.env.DOMAIN || `http://localhost:${PORT}`;

// --- In-memory usage store -------------------------------------------------
// sessionId -> { count: number, paid: boolean }
// NOTE: this resets whenever the server restarts. Fine for testing / a first
// launch. Before you rely on this for real revenue, swap it for a real store
// (a single Postgres/SQLite table with the same two columns is enough) so
// paid status survives deploys and server restarts. See README "Going to
// production" section.
const usage = new Map();

function getUsage(sessionId) {
  if (!usage.has(sessionId)) usage.set(sessionId, { count: 0, paid: false });
  return usage.get(sessionId);
}

// --- Stripe webhook must read the RAW body, so it's mounted before the
// json() body parser that every other route uses. ---------------------------
app.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  let event;
  try {
    const sig = req.headers['stripe-signature'];
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature check failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const sessionId = session.client_reference_id;
    if (sessionId) {
      const u = getUsage(sessionId);
      u.paid = true;
      console.log(`Marked session ${sessionId} as paid.`);
    }
  }

  res.json({ received: true });
});

app.use(express.json());
app.use(cookieParser());
app.use(express.static('public'));

// Assign every visitor a stable, anonymous session id via cookie.
app.use((req, res, next) => {
  let sessionId = req.cookies.sgid;
  if (!sessionId) {
    sessionId = uuidv4();
    res.cookie('sgid', sessionId, {
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24 * 365, // 1 year
      sameSite: 'lax',
    });
  }
  req.sessionId = sessionId;
  next();
});

const SYSTEM_PROMPT = `You are Scope Guard, a chat assistant for freelancers and consultants.

The user will paste a message from a client, or describe a request that feels
like it's outside the agreed project scope. Your job:
1. Identify whether it sounds like scope creep (a new ask not in the original deliverables).
2. If it does, write a short, professional reply the freelancer can send back — polite, firm, non-confrontational, that frames the extra work as a paid add-on rather than a favor.
3. Suggest a fair price range or time estimate for the add-on when there's enough info to guess (keep it a range, not a fake-precise number).
4. If the user's message isn't about scope/client boundaries at all, gently steer the conversation back: ask them to paste the client message or describe the situation.

Keep replies compact — a short reply script plus a one-line price/time suggestion. No long essays.`;

app.post('/api/chat', async (req, res) => {
  const { message, history } = req.body;
  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'Missing message' });
  }

  const u = getUsage(req.sessionId);

  if (!u.paid && u.count >= FREE_MESSAGE_LIMIT) {
    return res.status(402).json({
      error: 'paywall',
      message: "You've used your 5 free messages. Upgrade to keep going.",
    });
  }

  try {
    const messages = (Array.isArray(history) ? history : [])
      .slice(-10) // keep the payload small
      .concat([{ role: 'user', content: message }]);

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 500,
        system: SYSTEM_PROMPT,
        messages,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('Anthropic API error:', response.status, errText);
      return res.status(502).json({ error: 'The AI service failed. Try again shortly.' });
    }

    const data = await response.json();
    const reply = data.content.map((b) => (b.type === 'text' ? b.text : '')).join('\n').trim();

    if (!u.paid) u.count += 1;

    return res.json({
      reply,
      remainingFree: u.paid ? null : Math.max(0, FREE_MESSAGE_LIMIT - u.count),
      paid: u.paid,
    });
  } catch (err) {
    console.error('Chat error:', err);
    return res.status(500).json({ error: 'Something went wrong. Try again.' });
  }
});

app.get('/api/status', (req, res) => {
  const u = getUsage(req.sessionId);
  res.json({ remainingFree: u.paid ? null : Math.max(0, FREE_MESSAGE_LIMIT - u.count), paid: u.paid });
});

app.post('/api/create-checkout-session', async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription', // switch to 'payment' for a one-time charge instead of monthly
      line_items: [{ price: process.env.STRIPE_PRICE_ID, quantity: 1 }],
      client_reference_id: req.sessionId,
      success_url: `${DOMAIN}/?upgraded=1`,
      cancel_url: `${DOMAIN}/?upgraded=0`,
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error('Stripe checkout error:', err);
    res.status(500).json({ error: 'Could not start checkout.' });
  }
});

app.listen(PORT, () => {
  console.log(`Scope Guard running at ${DOMAIN}`);
});
