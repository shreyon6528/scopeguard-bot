# Scope Guard

A chatbot for freelancers: paste a client message, get back a reply that turns
scope creep into a paid add-on instead of free work. 5 free messages, then a
$9/month paywall via Stripe.

## What's here

- `server.js` — Express backend: chat endpoint (calls the Anthropic API),
  free-message counter, Stripe checkout + webhook to unlock unlimited use.
- `public/index.html` — the chat UI, single file, no build step.
- `.env.example` — copy to `.env` and fill in your real keys.

## 1. Local setup

```bash
npm install
cp .env.example .env
# open .env and fill in ANTHROPIC_API_KEY at minimum to test chat locally
npm start
```

Open `http://localhost:3000`. You'll be able to chat immediately — the
paywall pieces (Stripe) only kick in once you've configured them (step 3).

## 2. Get an Anthropic API key

1. Go to https://console.anthropic.com and create an account.
2. Settings → API Keys → Create Key.
3. Add a small amount of credit (this is pay-per-use, typically a fraction of
   a cent to a couple of cents per message with this model — nothing like a
   flat subscription cost to you).
4. Paste the key into `.env` as `ANTHROPIC_API_KEY`.

## 3. Set up Stripe (the paywall)

1. Create a free account at https://dashboard.stripe.com.
2. Stay in **test mode** while you build (toggle top-right).
3. Products → Add product → name it "Scope Guard Pro", set price $9/month,
   recurring. Save, then copy the **Price ID** (starts `price_...`) into
   `.env` as `STRIPE_PRICE_ID`.
4. Developers → API keys → copy the **Secret key** into `.env` as
   `STRIPE_SECRET_KEY`.
5. Webhook (so payment actually unlocks the account): easiest way to test
   locally is the Stripe CLI:
   ```bash
   stripe listen --forward-to localhost:3000/webhook
   ```
   It'll print a `whsec_...` value — put that in `.env` as
   `STRIPE_WEBHOOK_SECRET`. In production you'll instead add a webhook
   endpoint in the Stripe Dashboard pointing at `https://yourdomain.com/webhook`
   and use the signing secret it gives you there.
6. Test the full flow with Stripe's test card: `4242 4242 4242 4242`, any
   future expiry, any CVC.

Only switch Stripe out of test mode (and swap in live keys) once you've
actually run through a full test purchase successfully.

## 4. Deploy it somewhere real

Any Node host works. Two easy free-tier-friendly options:

**Render** (render.com): New → Web Service → connect your repo → build command
`npm install`, start command `npm start` → add your `.env` values under
Environment.

**Railway** (railway.app): New Project → Deploy from repo → add the same
environment variables in Settings → Variables.

After deploying, update `DOMAIN` in your environment variables to your real
URL, and update the Stripe webhook endpoint to point at
`https://your-real-domain.com/webhook`.

## Going to production (do this before real launch traffic)

The current usage tracker (`server.js`, the `usage` Map) is **in-memory** —
it resets to zero every time the server restarts or redeploys, which means a
paying customer could lose their "paid" status on a redeploy. Fine for
testing with friends; not fine once you have real paying customers. Before
a real launch, swap that Map for a one-table database (a single
`sessions` table with `id`, `count`, `paid` columns works — SQLite for
simplicity, Postgres if your host provides it free, e.g. Render/Railway both
do). Everywhere the code calls `getUsage(sessionId)`, `u.count`, or
`u.paid`, swap in a read/write to that table instead — the rest of the
logic doesn't change.

## Changing the price or free-message count

- Free message count: change `FREE_MESSAGE_LIMIT` at the top of `server.js`.
- Price: change it in the Stripe Dashboard (create a new Price, update
  `STRIPE_PRICE_ID`) — don't edit prices after customers have subscribed to
  them, create a new one instead.
- One-time payment instead of subscription: in `server.js`, change
  `mode: 'subscription'` to `mode: 'payment'` in
  `/api/create-checkout-session`.

## Changing what the bot does

Edit `SYSTEM_PROMPT` in `server.js`. That's the entire personality and
task definition — no other code changes needed to repurpose this into a
completely different chatbot.
